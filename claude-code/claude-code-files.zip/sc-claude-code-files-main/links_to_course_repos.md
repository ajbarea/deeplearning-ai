# Course Repository Links

## RAG Chatbot Project (Lessons 2-6)

- **[Starting Repository](https://github.com/https-deeplearning-ai/starting-ragchatbot-codebase.git)** - RAG chatbot codebase
    - Used as the foundation for Lessons 3, 4, and 5
    - Contains the initial setup and basic functionality
    
- **[Final Repository](https://github.com/https-deeplearning-ai/ragchatbot-codebase.git)** - Completed example
    - Shows the codebase state after Lesson 5
    - Includes all features added throughout the lessons

## Dashboard Project (Lesson 8)

- **[FRED Dashboard Repository](https://github.com/https-deeplearning-ai/FRED-dashboard.git)**
    - Complete dashboard implementation
    - Used in the final lesson of the course